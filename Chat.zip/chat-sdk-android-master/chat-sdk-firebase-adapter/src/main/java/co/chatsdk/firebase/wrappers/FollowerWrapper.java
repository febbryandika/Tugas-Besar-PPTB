package co.chatsdk.firebase.wrappers;

/**
 * Created by benjaminsmiley-andrews on 24/05/2017.
 */

public class FollowerWrapper {

    public FollowerWrapper () {

    }

}
