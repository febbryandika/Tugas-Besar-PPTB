1. **Is the bug present in the demo Chat SDK project?**

2. **What modifications have you made to the Chat SDK?**

3. **Android Version:**

4. **Steps taken to reproduce the problem:**

5. **Expected result:**

6. **Actual result:**

7. **Comments:**


