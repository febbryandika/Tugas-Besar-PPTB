package co.chatsdk.core.types;

/**
 * Created by benjaminsmiley-andrews on 06/07/2017.
 */

public enum ConnectionType {

    Contact,
    Friend,
    Follower,
    Blocked,

}
