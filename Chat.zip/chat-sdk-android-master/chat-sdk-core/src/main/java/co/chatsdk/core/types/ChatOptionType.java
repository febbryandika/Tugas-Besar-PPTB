package co.chatsdk.core.types;

/**
 * Created by ben on 10/11/17.
 */

public enum ChatOptionType {
    SendMessage
}
