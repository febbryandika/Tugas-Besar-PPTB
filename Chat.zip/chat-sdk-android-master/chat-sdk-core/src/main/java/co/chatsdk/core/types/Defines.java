package co.chatsdk.core.types;

/**
 * Created by benjaminsmiley-andrews on 04/05/2017.
 */

@Deprecated
public class Defines {

    /**
     * divide tat is used to divide b
     **/
    public static final String DIVIDER = ",";

    public static final class MessageDateFormat {
        public static final String YearOldMessageFormat = "MM/yy";
        public static final String DayOldFormat = "MMM dd";
        public static final String LessThenDayFormat = "HH:mm";
    }

    public static final String FROM_PUSH = "from_push";

}
