package co.chatsdk.core.error;

public class ChatSDKException extends Exception {

    public ChatSDKException(String message) {
        super(message);
    }

}
