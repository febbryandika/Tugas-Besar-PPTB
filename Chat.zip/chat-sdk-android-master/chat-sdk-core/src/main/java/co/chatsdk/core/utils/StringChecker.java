package co.chatsdk.core.utils;

/**
 * Created by ben on 9/4/17.
 */

public class StringChecker {

    public static boolean isNullOrEmpty (String string) {
        return string == null || string.isEmpty();
    }

}
