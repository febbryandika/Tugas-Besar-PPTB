package co.chatsdk.core.types;

/**
 * Created by benjaminsmiley-andrews on 03/05/2017.
 */

public class EntityType {

    public static final int User = 1;
    public static final int Thread = 2;
    public static final int Message = 3;

}
