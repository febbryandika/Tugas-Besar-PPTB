package co.chatsdk.core.handlers;

/**
 * Created by SimonSmiley-Andrews on 01/05/2017.
 */

public interface NearbyUsersHandler {


//    @protocol PNearbyUsersDelegate <NSObject>
//    - (void)userAdded: (id<PUser>)user location: (CLLocation *)location;
//    - (void)userRemoved: (id<PUser>)user;
//    - (void)userMoved: (id<PUser>)user location: (CLLocation *)location;
//
//    @end
//
//    @protocol PNearbyUsersHandler <NSObject>
//
//    -(void) findNearbyUsersWithRadius: (double) radiusInMetres;
//
//    -(RXPromise *)startUpdatingUserLocation;
//    -(void)stopUpdatingUserLocation;
//    -(CLLocation *)getCurrentLocation;
//    -(void) setDelegate: (id<PNearbyUsersDelegate>) delegate;
}
