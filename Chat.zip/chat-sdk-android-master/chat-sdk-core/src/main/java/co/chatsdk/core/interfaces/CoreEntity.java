package co.chatsdk.core.interfaces;

/**
 * Created by benjaminsmiley-andrews on 24/05/2017.
 */

public interface CoreEntity {

    void setEntityID (String entityID);
    String getEntityID ();

}
