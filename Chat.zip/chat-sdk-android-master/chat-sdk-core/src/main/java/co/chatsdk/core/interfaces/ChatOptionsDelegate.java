package co.chatsdk.core.interfaces;

/**
 * Created by ben on 10/11/17.
 */

public interface ChatOptionsDelegate {

    void executeChatOption (ChatOption option);

}
