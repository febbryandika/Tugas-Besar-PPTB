package co.chatsdk.core.defines;

/**
 * Created by ben on 8/23/17.
 */

public class Availability {

    public static String Available  = "available";
    public static String Unavailable  = "unavailable";
    public static String Chat = "chat";
    public static String Away  = "away";
    public static String Busy  = "dnd";
    public static String XA  = "xa";

}
